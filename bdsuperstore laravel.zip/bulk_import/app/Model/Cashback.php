<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Cashback extends Model
{
    protected $table = 'cashback';
    protected $primaryKey = 'id';
}
?>