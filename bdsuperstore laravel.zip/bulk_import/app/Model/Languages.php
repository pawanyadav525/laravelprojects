<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Languages extends Model
{
    protected $table = 'languages';
    protected $primaryKey = 'id';
}
?>