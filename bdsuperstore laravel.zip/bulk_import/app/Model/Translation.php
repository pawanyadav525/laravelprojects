<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Translation extends Model
{
    protected $table = 'ltm_translations';
    protected $primaryKey = 'id';
}
?>