<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Sepicalcategories extends Model
{
    protected $table = 'sepical_category';
    protected $primaryKey = 'id';
}
?>