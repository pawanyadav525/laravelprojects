<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Seasonaloffer extends Model
{
    protected $table = 'seasonal_offer';
    protected $primaryKey = 'id';

    
}
?>