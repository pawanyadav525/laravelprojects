<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Optionvalues extends Model
{
    protected $table = 'option_values';
    protected $primaryKey = 'id';
}
?>