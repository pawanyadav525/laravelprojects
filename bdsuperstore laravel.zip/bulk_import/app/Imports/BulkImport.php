<?php
namespace App\Imports;
use App\Model\Product;  
use App\Model\ProductAttributes; 
use App\Model\ProductOption; 
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use DB;
class BulkImport implements ToModel,WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
  
        $product = new Product;
        $product->name =$row['name'];
        $product->description =$row['desc'];
        $product->category =$row['cat'];
        $product->subcategory =$row['sub_cat'];
        $product->brand =$row['brand'];
        $product->tax_class =$row['tex_name'];
        $product->meta_keyword =$row['meta_keyword'];
        $product->color_name =$row['colr_name'];
        $product->product_color =$row['pro_clr'];
        $product->MRP =$row['mrp'];
        $product->price =$row['price'];
        $product->special_price =$row['spe_price'];
        $product->special_price_start =$row['spe_price_strt'];
        $product->special_price_to =$row['spe_price_end'];
        $product->basic_image =$row['image'];
        $product->additional_image =$row['adinl_image'];
        $product->url =$row['url'];
        $product->meta_title =$row['meta_title'];
        $product->meta_description =$row['meta_desc'];
        $product->name =$row['meta_keywrd'];
        $product->related_product =$row['related_pro'];
        $product->up_sells =$row['up_sells'];
        $product->cross_sells =$row['cross_sells'];
        $product->short_description =$row['short_desc'];
        $product->product_new_from =$row['prod_new_from'];
        $product->product_new_to =$row['pro_new_to'];
        $product->is_deleted =$row['is_dlted'];
        $product->discount =$row['discount'];
        $product->selling_price =$row['selling_price'];
        $product->status =$row['status'];
        $product->inventory =$row['inventry'];
        $product->stock =$row['stock'];
        $product->sku =$row['sku'];
        $product->save();
        
        
        $latest_product = DB::table('products')->select('id')->orderBy('id','DESC')->first();
        
        $product_attr = new ProductAttributes;
        $product_attr->product_id =$latest_product->id;
        $product_attr->attributeset =$row['attri_set'];
        $product_attr->attribute =$row['attri'];
        $product_attr->value =$row['value'];
        $product_attr->save();   
             
        $product_option = new ProductOption;     
        $product_option->product_id =$latest_product->id;
        $product_option->name =$row['option_name'];
        $product_option->type =$row['type'];
        $product_option->is_required =$row['is_req'];
        $product_option->label =$row['label'];
        $product_option->price =$row['opn_price'];
        $product_option->price_type =$row['opn_price_type'];
        
       $product_option->save();
       
                   
                   
       
    }
}

