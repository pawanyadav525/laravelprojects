<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Newsletter extends Model
{
    protected $table = 'news_letter';
    protected $primaryKey = 'id';

  
}
?>