<?php



namespace App\Model;



use Illuminate\Database\Eloquent\Model;



class ProductStage extends Model

{

    protected $table = 'product_stage';

    protected $primaryKey = 'id';
    protected $fillable = [ 'stage', 'product_id'];

}

?>