<?php



namespace App\Model;



use Illuminate\Database\Eloquent\Model;



class ProductModel extends Model

{

    protected $table = 'product_model';
    protected $fillable = [ 'id','model', 'product_id'];

}

?>