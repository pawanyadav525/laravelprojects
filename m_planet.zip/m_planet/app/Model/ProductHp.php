<?php



namespace App\Model;



use Illuminate\Database\Eloquent\Model;



class ProductHp extends Model

{

    protected $table = 'product_hp';
    protected $fillable = [ 'hp', 'product_id'];

}

?>