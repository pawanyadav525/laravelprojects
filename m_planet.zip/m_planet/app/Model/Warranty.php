<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Warranty extends Model
{
    protected $table = 'warranty';
    protected $primaryKey = 'id';
}
?>