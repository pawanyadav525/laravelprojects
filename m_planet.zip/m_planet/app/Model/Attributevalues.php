<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Attributevalues extends Model
{
    protected $table = 'attribute_values';
    protected $primaryKey = 'id';
}
?>