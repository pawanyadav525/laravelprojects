<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class OrderResponse extends Model
{
    protected $table = 'order_response';
    protected $primaryKey = 'id';
}
?>