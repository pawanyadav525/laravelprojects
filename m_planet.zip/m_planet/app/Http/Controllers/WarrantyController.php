<?php



namespace App\Http\Controllers;

use App\Http\Controllers\Controller as Controller;

use Illuminate\Http\Request;

use App\Http\Requests\LoginRequest;

use Sentinel;

use Session;

use DataTables;

use App\User;

use App\Model\Complain;

use App\Model\Product;

use App\Model\Warranty;

use Hash;

use Auth;

class WarrantyController extends Controller {



   public function index(){

      return view('admin.warranty.default');

   }



   public function warrantydatatable(){

         $category =Warranty::orderBy('id','DESC')->get();

         return DataTables::of($category)

            ->editColumn('id', function ($category) {

                return $category->id;

            })

            ->editColumn('email', function ($category) {

                return $category->email;

            }) 

             ->editColumn('purchase_date', function ($category) {

                 return date("d-M-y",strtotime($category->purchase_date));

            })

             ->editColumn('warranty_end', function ($category) {

                 return date("d-M-y",strtotime($category->warranty_end));

            })

               ->editColumn('created_at', function ($category) {

                 return date("d-M-y h:i:A",strtotime($category->created_at));

            })

          /*  ->editColumn('user_id', function ($category) {

                $user =  User::where('id',$category->user_id)->first();

                return $user->dealer_code." (".$user->first_name.")";

            })   

            */

            ->editColumn('action', function ($category) {

                 if(Session::get("is_demo")=='1')

                 {

                      return '<a  onclick="demofun()" rel="tooltip"  target="blank" class="m-b-10 m-l-5" data-original-title="Remove"><i class="fa fa-envelope f-s-25" style="margin-right: 10px;font-size: x-large;color:black"></i></a>';  

                 }

                 else{

                     $edit=url('admin/editcoupon',array('id'=>$category->id));

                     $delete=url('admin/deletecoupon',array('id'=>$category->id));

                     $return = '<a href="#" rel="tooltip"  user_id="'.$category->id.'" title="active" class="m-b-10 m-l-5 approveWarranty" data-original-title="Remove" style="margin-right: 10px;"><i class="fa fa-edit f-s-25" style="font-size: x-large;" data-toggle="modal" data-target="#exampleModal"></i></a><a onclick="delete_record(' . "'" . $delete. "'" . ')" rel="tooltip" title="Delete Category" class="m-b-10 m-l-5" data-original-title="Remove" style="margin-right: 10px;"><i class="fa fa-trash f-s-25" style="font-size: x-large;"></i></a>';     

                     return $return;              

                   }

                           

            })           

            ->make(true);

   }



   public function datatabletest(){

     $data=Warranty::orderBy('id','DESC')->paginate(10);

     return view("admin.datatable")->with("data",$data);

   }
   public function update_warranty_sts(Request $request){
    
      if($request->apporve !=null){
        Warranty::where('id','=',$request->user_id)->update([
          'status' => $request->apporve
        ]);
      }else{
         Warranty::where('id','=',$request->user_id)->update([
          'status' => $request->reject
        ]);
    }
   }


}