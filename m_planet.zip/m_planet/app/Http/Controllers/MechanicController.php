<?php



namespace App\Http\Controllers;

use App\Http\Controllers\Controller as Controller;

use Illuminate\Http\Request;

use App\Http\Requests\LoginRequest;

use Sentinel;

use Session;

use DataTables;

use App\User;

use App\Model\Complain;

use App\Model\Product;

use App\Model\Mechanic;

use Hash;

use Auth;

use DB;

class MechanicController extends Controller {



   public function index(){

      return view('admin.mechanic.default');

   }



   public function mechanicdatatable(){


           // $category=DB::table('mechanic')->select('mechanic.*','users.dealer_code')->join('users', 'mechanic.user_id', '=', 'users.id')->orderBy('mechanic.id','DESC');



         $category =Mechanic::orderBy('id','DESC')->get();
// dd($category);
         return DataTables::of($category)

            ->editColumn('id', function ($category) {

                return $category->id;

            }) 

               ->editColumn('created_at', function ($category) {

                 return date("d-M-y h:i:A",strtotime($category->created_at));

            })

            ->editColumn('user_id', function ($category) {

                $user =  User::where('id',$category->user_id)->first();

                if($user == null){

                    return 'No dealer';

                }else{

                return $user->dealer_code." (".$user->first_name.")";

                }

            })   

            

            ->editColumn('action', function ($category) {

                 if(Session::get("is_demo")=='1')

                 {

                      return '<a  onclick="demofun()" rel="tooltip"  target="blank" class="m-b-10 m-l-5" data-original-title="Remove">

                      <i class="fa fa-envelope f-s-25" style="margin-right: 10px;font-size: x-large;color:black"></i></a>';  

                 }

                 else{

                     $edit=url('admin/approve',array('id'=>$category->id));

                     $delete=url('admin/deletemechanic',array('id'=>$category->id));

                     $return = '<a href="#" user_id="'.$category->id.'" rel="tooltip" title="active" 

                     class="m-b-10 m-l-5 approveModal" data-original-title="Remove" 

                     style="margin-right: 10px;" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-edit f-s-25" 

                     style="font-size: x-large;"></i></a><a onclick="delete_record(' . "'" . $delete. "'" . ')" rel="tooltip" 

                     title="Delete Category" class="m-b-10 m-l-5" data-original-title="Remove" style="margin-right: 10px;">

                     <i class="fa fa-trash f-s-25" style="font-size: x-large;"></i></a>';     

                     return $return;                  }

                           

            })           

            ->make(true);

   }

public function deletemechanic($id){
   Mechanic::where('id','=',$id)->delete();
   return redirect()->back();
}

   public function datatabletest(){

    // $data=DB::table('mechanic')->select('mechanic.*','users.dealer_code')->join('users', 'mechanic.user_id', '=', 'users.id')->orderBy('mechanic.id','DESC')->paginate(10);

    

     $category =Mechanic::orderBy('id','DESC')->paginate(10);

     //dd($data);

     return view("admin.datatable")->with("data",$data);

   }
   public function update_sts(Request $request){
    //dd($request);
      if($request->apporve !=null){
        Mechanic::where('id','=',$request->user_id)->update([
          'status' => $request->apporve
        ]);
      }else{
         Mechanic::where('id','=',$request->user_id)->update([
          'status' => $request->reject,
          'reject_reason' =>$request->reson
        ]);

    }
   }



}