<?php
namespace App\Imports;
use App\Model\Product;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
class BulkImport implements ToModel,WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {

       Product::where('id', $row['id'])
       ->update([
           'hp' => $row['hp'],
           'stage' => $row['stage'],
           'pump_size' => $row['pump_size'],
        ]);

    }
}